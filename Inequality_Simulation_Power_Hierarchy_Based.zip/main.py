# Simulating Stage 3 inequality evolution based on Power-based hierarchy
import numpy as np
import matplotlib.pyplot as plt

# --- Robust Gini coefficient ---
def gini(x):
    x = np.array(x, dtype=float)
    total = np.sum(x)
    if total <= 0 or np.isnan(total):
        return 0.0
    x = np.sort(x)
    n = len(x)
    cumx = np.cumsum(x)
    return (n + 1 - 2 * np.sum(cumx) / cumx[-1]) / n

# --- Stable logistic win probability ---
def win_prob(w_i, w_j, k=0.001):
    diff = np.clip(w_i - w_j, -1000, 1000)  # prevent overflow
    return 1.0 / (1.0 + np.exp(-k * diff))

# --- Parameters ---
num_agents = 1000
num_steps = 1000
rng = np.random.default_rng(42)

# Initial wealth: lognormal body with lower bound
wealth = rng.lognormal(mean=4.5, sigma=0.3, size=num_agents)
wealth = np.clip(wealth, 20, None)

# Growth parameters
base_mu = 0.004      # baseline drift
base_sigma = 0.01    # volatility
adv_scale = 0.001    # incremental drift advantage for above-median wealth

# Exchange parameters
exchanges_per_step = 200
base_frac = 0.017     # fraction of winner’s wealth transferred
cap_frac = 0.02      # cap transfer

# Redistribution
tax_rate = 0.005     # 0.5% tax on top decile
bottom_target_share = 1.0

gini_history = []

for t in range(num_steps):
    # 1) Multiplicative growth with smooth wealth-based advantage
    median_w = np.median(wealth)
    advantage = adv_scale * (wealth / (median_w + 1e-9) - 1.0)
    mu = base_mu + advantage
    eps = rng.standard_normal(num_agents)
    exponent = mu + base_sigma * eps
    exponent = np.clip(exponent, -0.1, 0.1)  # prevent overflow
    growth = np.exp(exponent)
    wealth *= growth
    wealth = np.clip(wealth, 0, 1e6)

    # 2) Preferential exchanges
    for _ in range(exchanges_per_step):
        i, j = rng.integers(0, num_agents, size=2)
        if i == j:
            continue
        p_i_wins = win_prob(wealth[i], wealth[j], k=0.001)
        i_wins = rng.random() < p_i_wins
        winner, loser = (i, j) if i_wins else (j, i)

        transfer = base_frac * wealth[winner]
        transfer = min(transfer, cap_frac * wealth[winner], wealth[loser])
        if transfer > 0:
            wealth[winner] += transfer
            wealth[loser] -= transfer

    # 3) Redistribution: tax top decile, give to bottom decile
    order = np.argsort(wealth)
    bottom_idx = order[:num_agents // 10]
    top_idx = order[-num_agents // 10:]
    tax_pool = np.sum(wealth[top_idx] * tax_rate)
    wealth[top_idx] *= (1 - tax_rate)
    wealth[bottom_idx] += (tax_pool * bottom_target_share) / len(bottom_idx)

    # 4) Clean up
    wealth = np.nan_to_num(wealth, nan=0.0, posinf=1e6, neginf=0.0)
    gini_history.append(gini(wealth))

# --- Plots (inline only) ---
plt.style.use("default")

plt.figure(figsize=(10, 4))
plt.plot(gini_history, color="crimson")
plt.xlabel("Time step")
plt.ylabel("Gini coefficient")
plt.title("Stage 3: Gini evolution (continuous advantage)")
plt.grid(True, alpha=0.3)
plt.show()

plt.figure(figsize=(10, 5))
plt.hist(wealth, bins=60, color="steelblue", edgecolor="black")
plt.xlabel("Wealth")
plt.ylabel("Agents")
plt.title("Stage 3: Final wealth distribution")
plt.grid(True, alpha=0.3)
plt.show()

plt.figure(figsize=(10, 5))
plt.hist(wealth, bins=60, color="darkgreen", edgecolor="black")
#plt.xscale("log")
#plt.xlabel("Wealth (log scale)")
plt.xlabel("Wealth")
plt.ylabel("Agents")
plt.title("Stage 3: Final wealth distribution (log scale)")
plt.title("Stage 3: Final wealth distribution")
plt.grid(True, which="both", axis="x", alpha=0.3)
plt.show()

print("Final mean wealth:", np.mean(wealth))
print("Final variance of wealth:", np.var(wealth))
print("Final Gini coefficient:", gini(wealth))


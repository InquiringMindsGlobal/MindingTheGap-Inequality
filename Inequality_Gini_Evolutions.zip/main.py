# Plotting Gini evolution for all three stages on a single figure
import numpy as np
import matplotlib.pyplot as plt

# Simulated Gini histories for demonstration purposes
np.random.seed(42)
gini_history_stage1 = np.linspace(0.2, 0.3, 1000) + np.random.normal(0, 0.005, 1000)
gini_history_stage2 = np.linspace(0.3, 0.4, 1000) + np.random.normal(0, 0.005, 1000)
gini_history_stage3 = np.linspace(0.4, 0.6, 1000) + np.random.normal(0, 0.01, 1000)

# Plot all three Gini trajectories
plt.style.use("default")
plt.figure(figsize=(12, 6))
plt.plot(gini_history_stage1, label='Luck (Stage 1)', color='blue')
plt.plot(gini_history_stage2, label='Merit (Stage 2)', color='green')
plt.plot(gini_history_stage3, label='Power (Stage 3)', color='red')
plt.title("Comparison of Gini Evolution Across Stages")
plt.xlabel("Time step")
plt.ylabel("Gini coefficient")
plt.legend()
plt.grid(True)
plt.show()

print("Displayed Gini evolution comparison across Stage 1 (Luck), Stage 2 (Merit), and Stage 3 (Power)")


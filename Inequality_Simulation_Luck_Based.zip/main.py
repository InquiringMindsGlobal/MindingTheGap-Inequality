# Simulating stochastic emergence of inequality from random exchanges and shocks
import numpy as np
import matplotlib.pyplot as plt

# Set random seed for reproducibility
np.random.seed(42)

# Parameters
num_agents = 1000
initial_wealth = np.random.uniform(50, 150, num_agents)
wealth = initial_wealth.copy()
num_steps = 1000
gini_history = []

def gini_coefficient(x):
    """Compute Gini coefficient of array x."""
    sorted_x = np.sort(x)
    n = len(x)
    cumx = np.cumsum(sorted_x)
    return (n + 1 - 2 * np.sum(cumx) / cumx[-1]) / n

# Simulation loop
for step in range(num_steps):
    # Random pairwise exchanges
    for _ in range(num_agents // 2):
        i, j = np.random.choice(num_agents, 2, replace=False)
        exchange_fraction = 0.01
        delta = exchange_fraction * min(wealth[i], wealth[j])
        if np.random.rand() < 0.5:
            wealth[i] -= delta
            wealth[j] += delta
        else:
            wealth[j] -= delta
            wealth[i] += delta

    # Random shocks: windfalls or losses
    shock_indices = np.random.choice(num_agents, size=num_agents // 20, replace=False)
    shocks = np.random.normal(0, 5, size=shock_indices.shape[0])
    wealth[shock_indices] += shocks
    wealth = np.clip(wealth, 0, None)  # Ensure no negative wealth

    # Record Gini coefficient
    gini = gini_coefficient(wealth)
    gini_history.append(gini)

# Plot Gini coefficient evolution
plt.figure(figsize=(10, 5))
plt.plot(gini_history, color='darkred')
plt.title("Gini Coefficient Over Time (Stochastic Inequality Simulation)")
plt.xlabel("Time Step")
plt.ylabel("Gini Coefficient")
plt.grid(True)
plt.tight_layout()
plt.show()

# Plot final wealth distribution
plt.figure(figsize=(10, 5))
plt.hist(wealth, bins=50, color='steelblue', edgecolor='black')
plt.title("Final Wealth Distribution After 1000 Steps")
plt.xlabel("Wealth")
plt.ylabel("Number of Agents")
plt.grid(True)
plt.tight_layout()
plt.show()

print("Displayed Gini coefficient evolution and final wealth distribution histogram from stochastic simulation.")


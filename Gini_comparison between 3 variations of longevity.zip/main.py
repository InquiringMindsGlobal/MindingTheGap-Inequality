# Comparing inequality between 3 variations of hierarchy longevity
import numpy as np
import matplotlib.pyplot as plt

# --- Agent definition with longevity ---
class ResourceAgent:
    def __init__(self, agent_id, initial_wealth=None, skill=None, longevity=None):
        self.id = agent_id
        self.wealth = initial_wealth if initial_wealth is not None else np.random.randint(1, 5)
        self.skill = skill if skill is not None else np.random.choice(["low", "high"])
        self.age = 0
        # Lifespan in steps: individuals short-lived, institutions long-lived
        self.longevity = longevity if longevity is not None else np.random.randint(80, 120)

    def step(self, model):
        # Multiplicative growth
        growth_rate = 0.03 if self.skill == "high" else 0.015
        self.wealth *= (1 + growth_rate)

        # Preferential attachment
        prob = min(self.wealth / 50, 0.6)
        if np.random.rand() < prob:
            self.wealth += max(1, 0.1 * self.wealth)

        # Scarcity constraint
        claim = 1 if self.skill == "high" else 0.5
        available = min(claim, model.resource_pool)
        model.resource_pool -= available
        self.wealth += available

        # Age increment
        self.age += 1

    def is_alive(self):
        return self.age < self.longevity


# --- Model definition with longevity ---
class HierarchyModel:
    def __init__(self, N, horizon=300, generation=100, inheritance_rate=0.7, resource_pool=200, hierarchy=True, longevity_mode=True):
        self.agents = [ResourceAgent(i) for i in range(N)]
        self.history = []
        self.horizon = horizon
        self.generation = generation
        self.inheritance_rate = inheritance_rate
        self.resource_pool = resource_pool
        self.hierarchy = hierarchy
        self.longevity_mode = longevity_mode

    def step(self, t):
        # Reset resource pool each step
        self.resource_pool = 200
        for agent in self.agents:
            agent.step(self)

        # Remove dead agents if longevity is active
        if self.longevity_mode:
            self.agents = [a for a in self.agents if a.is_alive()]

        # Generational turnover
        if (t + 1) % self.generation == 0:
            new_agents = []
            for a in self.agents:
                if self.hierarchy:
                    # Inheritance: wealth persists
                    child = ResourceAgent(a.id, longevity=a.longevity)
                    child.wealth = a.wealth * self.inheritance_rate
                    child.skill = a.skill
                    new_agents.append(child)
                else:
                    # Reset wealth: no inheritance
                    child = ResourceAgent(a.id, longevity=a.longevity)
                    child.wealth = np.random.randint(1, 5)
                    child.skill = a.skill
                    new_agents.append(child)
            self.agents = new_agents

        self.history.append(self.compute_gini())

    def compute_gini(self):
        wealths = np.array([a.wealth for a in self.agents])
        if wealths.sum() == 0:
            return 0
        sorted_w = np.sort(wealths)
        n = len(sorted_w)
        cumw = np.cumsum(sorted_w)
        return (n + 1 - 2 * np.sum(cumw) / cumw[-1]) / n


# --- Run both models ---
if __name__ == "__main__":
    horizon = 300
    model_h = HierarchyModel(N=50, horizon=horizon, hierarchy=True, longevity_mode=True)
    model_nh = HierarchyModel(N=50, horizon=horizon, hierarchy=False, longevity_mode=True)

    for t in range(horizon):
        model_h.step(t)
        model_nh.step(t)

    # Print final inequality
    print("Final Gini (Hierarchy + Longevity):", model_h.history[-1])
    print("Final Gini (No Hierarchy + Longevity):", model_nh.history[-1])

    # Plot overlay
    plt.plot(model_h.history, label="Hierarchy (Inheritance + Longevity)", color="red")
    plt.plot(model_nh.history, label="No Hierarchy (Reset + Longevity)", color="blue")

    # Mark generational turnover
    for gen in [100, 200]:
        plt.axvline(x=gen, color='gray', linestyle='--')
        plt.text(gen+2, max(model_h.history)*0.9, "Generational Turnover", rotation=90, color='gray')

    plt.xlabel("Step")
    plt.ylabel("Gini coefficient")
    plt.title("Comparison: Inequality With vs. Without Structural Hierarchy (Longevity Enabled)")
    plt.legend()
    plt.show()


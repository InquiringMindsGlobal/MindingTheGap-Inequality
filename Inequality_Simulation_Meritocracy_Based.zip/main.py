# Simulating stochastic emergence of inequality based on Meritocracy model
import numpy as np
import matplotlib.pyplot as plt

# --- Helper: Gini coefficient ---
def gini_coefficient(x):
    """Compute Gini coefficient of array x."""
    x = np.sort(x)
    n = len(x)
    cumx = np.cumsum(x)
    return (n + 1 - 2 * np.sum(cumx) / cumx[-1]) / n

# --- Simulation parameters ---
n_agents = 1000
n_steps = 1000

# Productivity scores (drawn from normal distribution, clipped to positive)
productivity = np.clip(np.random.normal(loc=1.0, scale=0.3, size=n_agents), 0.1, None)

# Initial wealth (all equal to highlight merit effects)
wealth = np.ones(n_agents) * 100

# Savings rate linked to productivity (higher productivity → higher savings)
savings_rate = np.clip(0.2 + 0.3 * (productivity / productivity.max()), 0.2, 0.5)

gini_values = []

# --- Simulation loop ---
for t in range(n_steps):
    # Each agent earns income proportional to productivity
    income = productivity * 10
    wealth += income

    # Agents save a fraction of their wealth
    wealth = wealth * (1 + savings_rate * 0.01)

    # Random pair exchange (still present, but less dominant than productivity)
    i, j = np.random.randint(0, n_agents, 2)
    if i != j:
        transfer = 0.05 * wealth[i]
        wealth[i] -= transfer
        wealth[j] += transfer

    # Track Gini
    gini_values.append(gini_coefficient(wealth))

# --- Final wealth distribution ---
final_wealth = wealth

# --- Plot Gini evolution ---
plt.figure(figsize=(10, 4))
plt.plot(gini_values, label="Gini coefficient")
plt.xlabel("Time step")
plt.ylabel("Gini")
plt.title("Stage 2: Gini evolution (Meritocracy-based)")
plt.legend()
plt.show()

# --- Histogram of final wealth ---
plt.figure(figsize=(10, 5))
plt.hist(final_wealth, bins=30, density=True, alpha=0.6, color="skyblue", label="Final wealth")
plt.xlabel("Wealth")
plt.ylabel("Density")
plt.title("Stage 2: Wealth distribution (Meritocracy)")
plt.legend()
plt.show()

# --- Summary stats ---
print("Final mean wealth:", np.mean(final_wealth))
print("Final variance of wealth:", np.var(final_wealth))
print("Final Gini coefficient:", gini_coefficient(final_wealth))
